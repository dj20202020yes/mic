from django.shortcuts import render, redirect
from django.template import loader
from django.http import HttpResponse
from sales.forms import SalesForm
from sales.models import Sales


# def index(request):
#     template = loader.get_template('sales/index.html')
#     return HttpResponse(template.render())


def emp(request):
    if request.method == "POST":
        form = SalesForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/sales/show")
    else:
        form = SalesForm()
    return render(request, 'sales/index.html', {'form': form})


def show(request):
    sales = Sales.objects.all()
    return render(request, "sales/show.html", {'sales': sales})


def edit(request, id):
    sales = Sales.objects.get(id=id)
    return render(request, 'sales/edit.html', {'sales': sales})


def update(request, id):
    sales = Sales.objects.get(id=id)
    form = SalesForm(request.POST, instance=sales)
    if form.is_valid():
        form.save()
        return redirect("/sales/show")
    return render(request, 'sales/edit.html', {'sales': sales})


def destroy(request, id):
    employee = Sales.objects.get(id=id)
    employee.delete()
    return redirect("/sales/show")
