from django.contrib import admin
from sales.models import Sales


class SalesAdmin(admin.ModelAdmin):
    list_display = ['id', 'client', 'end_user', 'description', 'model_serial_no', 'qty', 'gate_pass',
                    'category', 'sales_date']

admin.site.register(Sales, SalesAdmin)






